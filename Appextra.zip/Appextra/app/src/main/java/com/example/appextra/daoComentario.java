package com.example.appextra;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import java.util.ArrayList;

public class daoComentario{
    Context c;
    Comentar u;
    ArrayList<Comentar> lista;
    SQLiteDatabase sql;
    String bd= "BDComentarios";
    String tabla="create table if not exists comentarios(id integer primary key autoincrement, titulo text,comentario text, autor text)";

    public daoComentario(Context c){
        this.c=c;
        sql=c.openOrCreateDatabase(bd,c.MODE_PRIVATE,null);
        sql.execSQL(tabla);
        u=new Comentar();
    }

    public boolean insertComentario(Comentar u){
        if(buscar(u.getComentario())==0){
            ContentValues cv=new ContentValues();
            cv.put("titulo",u.getTitulo());
            cv.put("comentario",u.getComentario());
            cv.put("autor",u.getAutor());
            return (sql.insert("comentarios",null,cv)>0);
        }else{
            return false;
        }
    }
    public int buscar(String u){
        int x=0;
        lista=selectComentarios();
        for (Comentar us:lista){
            if (us.getComentario().equals(u)){
                x++;
            }
        }
        return x;
    }

    public ArrayList<Comentar> selectComentarios() {
        ArrayList<Comentar>lista=new ArrayList<Comentar>();
        Cursor cr=sql.rawQuery("select * from comentarios",null);
        if(cr!=null && cr.moveToFirst()){
            do{
                Comentar u=new Comentar();
                u.setId(cr.getInt(0));
                u.setTitulo(cr.getString(1));
                u.setComentario(cr.getString(2));
                u.setAutor(cr.getString(3));
                lista.add(u);
            }while (cr.moveToNext());
        }
        return lista;
    }

    public Comentar getComentario(String u,String p){
        lista=selectComentarios();
        for(Comentar us:lista){
            if (us.getTitulo().equals(u)&& us.getComentario().equals(p)){
                return us;
            }

        }
        return null;
    }
    public Comentar getComentarioByID(int id){
        lista=selectComentarios();
        for(Comentar us:lista){
            if (us.getId()==id){
                return us;
            }
        }
        return null;
    }


}
