package com.example.appextra;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import java.util.ArrayList;

public class Mostrar extends AppCompatActivity {
    ListView    Lista;
    daoUsuario dao;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.mostrar);

        Lista=(ListView)findViewById(R.id.Lista);
        dao=new daoUsuario(this);

        ArrayList<Usuario>l=dao.selectUsuarios();
        ArrayList<String> list=new ArrayList<String>();
        for (Usuario u:l) {
        list.add("Usuario -> "+u.getNombre()+" "+ u.getApellidos()+" ");
    }
        ArrayAdapter<String> a=new ArrayAdapter<String>(this, android.R.layout.simple_expandable_list_item_1,list);
        Lista.setAdapter(a);

    }
}