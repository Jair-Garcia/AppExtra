package com.example.appextra;

import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class Chat extends AppCompatActivity implements View.OnClickListener {

    Button btnpublicar,btnmostrarp, btnusuarios, btnSalir;
    TextView nombre;
    int id=0;
    Usuario u;
    daoUsuario dao;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.chat);

        nombre=(TextView)findViewById(R.id.nombreUsuario);

        btnpublicar = (Button) findViewById(R.id.btnpublicar);
        btnmostrarp = (Button) findViewById(R.id.btnMostrarchat);
        btnusuarios = (Button) findViewById(R.id.btnUsuarioschat);
        btnSalir = (Button) findViewById(R.id.btnSalirchat);

        btnpublicar.setOnClickListener(this);
        btnSalir.setOnClickListener(this);
        btnmostrarp.setOnClickListener(this);
        btnusuarios.setOnClickListener(this);

        Bundle b=getIntent().getExtras();
        dao=new daoUsuario(this);
        id=b.getInt("Id");

        u=dao.getUsuarioByID(id);
        nombre.setText("Bienvenido: "+ u.getNombre() + " " + u.getApellidos());

    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.btnpublicar:
            Intent f = new Intent(Chat.this, Publicar.class);
                f.putExtra("Id",id);
            startActivity(f);

            break;

            case R.id.btnMostrarchat:
            Intent a = new Intent(Chat.this, MostrarChat.class);
                a.putExtra("Id",id);
            startActivity(a);
            break;

            case R.id.btnUsuarioschat:
            Intent c = new Intent(Chat.this, Inicio.class);
                c.putExtra("Id",id);
                startActivity(c);

            break;
            case R.id.btnSalirchat:
            Intent d = new Intent(Chat.this, MainActivity.class);
            d.putExtra("Id",id);
            startActivity(d);
            finish();
            break;

        }
    }
}