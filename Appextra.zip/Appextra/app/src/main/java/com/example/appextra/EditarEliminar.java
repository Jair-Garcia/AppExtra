package com.example.appextra;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;

public class EditarEliminar extends AppCompatActivity implements View.OnClickListener{
    ListView    Lista;
    EditText eltitulo;
    Button btnelim,btnelsal;
    daoUsuario dao;
    int id=0;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.editareliminar);
        Bundle b=getIntent().getExtras();
        id=b.getInt("Id");

        Lista=(ListView)findViewById(R.id.Lista);
        dao=new daoUsuario(this);
        eltitulo=(EditText)findViewById(R.id.elid);
        btnelim=(Button) findViewById(R.id.btnEliminar);
        btnelsal=(Button) findViewById(R.id.btnelsalir);

        btnelsal.setOnClickListener(this);
        btnelim.setOnClickListener(this);
        dao=new daoUsuario(this);

        ArrayList<Usuario>l=dao.selectUsuarios();
        ArrayList<String> list=new ArrayList<String>();
        for (Usuario u:l) {
        list.add("ID "+"  "+u.getId()+"  "+u.getNombre()+"  "+ u.getApellidos());
    }
        ArrayAdapter<String> a=new ArrayAdapter<String>(this, android.R.layout.simple_expandable_list_item_1,list);
        Lista.setAdapter(a);

    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.btnEliminar:
            case R.id.btnEntrar:
                String nombre=eltitulo.getText().toString();

                if (nombre.equals("")){
                    Toast.makeText(this, "Campos Vacios", Toast.LENGTH_SHORT).show();
                }else if (dao.logout(nombre)==1){
                    dao.deleteUsuario(nombre);
                    Toast.makeText(this, "Eliminado", Toast.LENGTH_SHORT).show();
                    Intent i2=new Intent(EditarEliminar.this,Inicio.class);
                    i2.putExtra("Id",id);
                    startActivity(i2);
                }else{
                    Toast.makeText(this, "Campos Erroneos", Toast.LENGTH_SHORT).show();

                }


                break;
            case R.id.btnelsalir:
                Intent i=new Intent(EditarEliminar.this, Inicio.class);
                i.putExtra("Id",id);
                startActivity(i);
                break;


        }


    }
}