package com.example.appextra;

public class Comentar{
    int Id;
    String Titulo,Comentario,Autor;
    public Comentar(){
    }

    public Comentar(String titulo, String comentario, String autor) {
        Titulo = titulo;
        Comentario = comentario;
        Autor = autor;
    }
    public boolean isNull(){
        if(Titulo.equals("")&&Comentario.equals("")&&Autor.equals("")){
            return false;
        }else {
            return true;
        }
    }

    @Override
    public String toString() {
        return "Comentar{" +
                "Id=" + Id +
                ", Titulo='" + Titulo + '\'' +
                ", Comentario='" + Comentario + '\'' +
                ", Autor='" + Autor + '\'' +
                '}';
    }

    public int getId() {
        return Id;
    }

    public void setId(int id) {
        Id = id;
    }

    public String getTitulo() {
        return Titulo;
    }

    public void setTitulo(String titulo) {
        Titulo = titulo;
    }

    public String getComentario() {
        return Comentario;
    }

    public void setComentario(String comentario) {
        Comentario = comentario;
    }

    public String getAutor() {
        return Autor;
    }

    public void setAutor(String autor) {
        Autor = autor;
    }
}
