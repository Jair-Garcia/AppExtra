package com.example.appextra;


import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;


public class Publicar extends AppCompatActivity  implements View.OnClickListener{
    EditText titulo,coment,autor;
    Button com,canc;
    daoComentario dao;
    int id=0;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.publicar);
        titulo=(EditText)findViewById(R.id.pubtitulo);
        coment=(EditText)findViewById(R.id.pubcomentario);
        autor=(EditText)findViewById(R.id.pubautor);

        com=(Button) findViewById(R.id.btnpubagregar);
        canc=(Button) findViewById(R.id.btnpubcancelar);

        com.setOnClickListener(this);
        canc.setOnClickListener(this);
        dao=new daoComentario(this);
        Bundle b=getIntent().getExtras();
        id=b.getInt("Id");
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.btnpubagregar:
                Comentar u=new Comentar();
                u.setTitulo(titulo.getText().toString());
                u.setComentario(coment.getText().toString());
                u.setAutor(autor.getText().toString());
                if (!u.isNull()){
                    Toast.makeText(this, "Campos vacíos", Toast.LENGTH_SHORT).show();
                }else if(dao.insertComentario(u)){
                    Toast.makeText(this, "¡Comentario Publicado!", Toast.LENGTH_SHORT).show();
                    Intent i2=new Intent(Publicar.this, Chat.class);
                    i2.putExtra("Id",id);

                    startActivity(i2);
                    finish();
                }else{
                    Toast.makeText(this, "¡Comentario Repetido!", Toast.LENGTH_SHORT).show();
                }


                break;
            case R.id.btnpubcancelar:
                Intent i=new Intent(Publicar.this, Chat.class);
                i.putExtra("Id",id);
                startActivity(i);
                finish();
                break;


        }


    }
}