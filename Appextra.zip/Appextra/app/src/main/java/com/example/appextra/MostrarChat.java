package com.example.appextra;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import java.util.ArrayList;

public class MostrarChat extends AppCompatActivity {
        ListView    Lista;
        daoComentario dao;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.mostrarchat);
        Lista=(ListView)findViewById(R.id.Lista);
        dao=new daoComentario(this);
        ArrayList<Comentar>l=dao.selectComentarios();
        ArrayList<String> list=new ArrayList<String>();
        for (Comentar u:l) {
            list.add(u.getId()+" "+u.getTitulo()+" "+ u.getComentario()+" "+ u.getAutor()+" ");
        }
        ArrayAdapter<String> a=new ArrayAdapter<String>(this, android.R.layout.simple_expandable_list_item_1,list);
        Lista.setAdapter(a);

    }
}